open Core.Std
open Ir

let svg_preamble w h = sprintf "<?xml version=\"1.0\"?><svg viewBox=\"0 0 %d %d\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\"><g stroke=\"black\" fill=\"black\">" w h ;;

let svg_end = "</g></svg>" ;;

(* TODO: xml_encode_string (for <, >, maybe others)  *)

let shape_to_svg : raw_shape -> string = function
    Invalid -> ""
  | Line(x1, y1, x2, y2) -> sprintf "<line x1=\"%ld\" y1=\"%ld\" x2=\"%ld\" y2=\"%ld\" />" x1 y1 x2 y2
  | Text(x, y, s) -> sprintf "<text x=\"%ld\" y=\"%ld\">%s</text>" x y s
  | Box(x, y, w, h) -> sprintf "<rect x=\"%ld\" y=\"%ld\" width=\"%ld\" height=\"%ld\" />" x y w h
  | Ellipse(x, y, hr, vr) -> sprintf "<ellipse cx=\"%ld\" cy=\"%ld\" rx=\"%ld\" ry=\"%ld\" />" x y hr vr
;;

(* width, height, shapes -> SVG *)
let to_svg w h shapes : string =
  String.concat ([svg_preamble w h] @ (List.map shapes shape_to_svg) @ [svg_end])
;;
