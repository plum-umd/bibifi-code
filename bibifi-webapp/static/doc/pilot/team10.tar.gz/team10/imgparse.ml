open Core.Std
open Rterror
open Astutil

let main (_ : unit)  : unit = printf "%s" (print_prog (parse_file Sys.argv.(1)));;

let () = handle_runtime_errors main;

