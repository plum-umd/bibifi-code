#!/usr/bin/env bash
sudo add-apt-repository -y ppa:avsm/ppa
sudo apt-get update -y
sudo apt-get install -y ocaml m4 opam
opam init -y
opam install -y ocamlfind
opam install -y core
