open Core.Std

(* Error Type Declarations *) 

type runtime_error =   
   Syntax_Error
  | Type_Error
  | Arity_Error
  | Already_Destroyed
  | Negative_Size
  | Undeclared_Variable
  | Already_Declared;;

exception Runtime_Exp of runtime_error * string;;

let throw_runtime_exp (r : runtime_error): string -> 'a = 
  (fun s -> raise (Runtime_Exp (r,s)));;

let syntax_error : string -> 'a = throw_runtime_exp Syntax_Error ;;
let type_error : string -> 'a = throw_runtime_exp Type_Error ;;
let arity_error : string -> 'a = throw_runtime_exp Arity_Error ;;
let destruction_error : string -> 'a = throw_runtime_exp Already_Destroyed ;;
let negative_size_error : string -> 'a = throw_runtime_exp Negative_Size;;
let undeclared_var_error : string -> 'a = throw_runtime_exp Undeclared_Variable;;
let redeclaration_error : string -> 'a = throw_runtime_exp Already_Declared;;

let print_runtime_error (r : runtime_error) (s : string) : unit = match r with
    Syntax_Error -> printf "Syntax Error : %s \n" s; exit 10;
  | Type_Error -> printf "Type Error : %s \n" s; exit 20; 
  | Arity_Error -> printf "Procedure Arity Error : %s \n" s; exit 20; 
  | Already_Destroyed -> printf "Variable Already Destroyed : %s \n" s; exit 30; 
  | Negative_Size -> printf "Negative Size Value : %s \n" s; exit 40; 
  | Undeclared_Variable -> printf "Using Undeclared Variable : %s \n" s; exit 50;
  | Already_Declared -> printf "Trying to Redeclare Variable : %s \n" s; exit 60;;

let handle_runtime_errors (f : unit -> unit) : unit =
  try f () with 
     Runtime_Exp(r,s) -> print_runtime_error r s
   | e -> raise e;;
