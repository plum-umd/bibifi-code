open Core.Std
open Ir
open Int32
open Polymorphic_compare
open Rterror

let new_table (n : env) (vl : value list) : value = match vl with
  | n::[] -> (match n with 
      | Data(Int(i)) -> if i < Int32.zero then 
              negative_size_error "Tried to initialize table with negative size."
          else
              Data(Table(Hashtbl.Poly.create ()))
      | _ -> type_error "Tried to init table with non integer value")
  | _ -> arity_error "Procedure @newTable called with the wrong number of arguments";;

let cat (n : env) (vl : value list) : value = match vl with 
  | Data(String(a))::Data(String(b))::[] -> Data(String(String.concat [a;b]))
  | _ -> type_error "Procedure @cat called with invalid parameters";;

let shift_shape x y = function 
    Invalid -> Invalid 
  | Line(a,b,c,d) -> Line(a + x,b + y,c + x,d + y) 
  | Text(a,b,c) -> Text(a + x,b + y,c)
  | Box(a,b,c,d) -> Box(a + x,b + y,c,d)
  | Ellipse(a,b,c,d) -> Ellipse(a + x,b + y,c,d);;

let mult_shape x = function 
    Invalid -> Invalid 
  | Line(a,b,c,d) -> Line(a * x,b * x,c * x,d * x) 
  | Text(a,b,c) -> Text(a * x,b * x,c)
  | Box(a,b,c,d) -> Box(a * x,b * x,c,d)
  | Ellipse(a,b,c,d) -> Ellipse(a * x,b * x,c,d);;

let div_shape x = function 
    Invalid -> Invalid 
  | Line(a,b,c,d) -> Line(a / x,b / x,c / x,d / x) 
  | Text(a,b,c) -> Text(a / x,b / x,c)
  | Box(a,b,c,d) -> Box(a / x,b / x,c,d)
  | Ellipse(a,b,c,d) -> Ellipse(a / x,b / x,c,d);;

(* TODO : add shape and group code *) 
let add (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(a + b))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (shift_shape 0l b (!s))))
  | _ -> type_error "Procedure @add called with invalid parameters";; 

(* TODO : add shape and group code *) 
let sub (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(a - b))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (shift_shape 0l (-1l * b) (!s))))
  | _ -> type_error "Procedure @sub called with invalid parameters";; 
 
(* TODO : add shape and group code *) 
let mul (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(a * b))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (mult_shape b (!s))))
  | _ -> type_error "Procedure @mul called with invalid parameters";; 
 
(* TODO : add shape and group code *) 
let modulo (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(Int32.rem a b))
  | Shape(s)::Data(Int(b))::[] -> failwith "Not Implemented Yet"
  | _ -> type_error "Procedure @mod called with invalid parameters";;
 
(* TODO : add shape and group code *) 
let div (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(a / b))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (div_shape b (!s))))
  | _ -> type_error "Procedure @div called with invalid parameters";;

(* TODO : add shape and group code *) 
let lshift (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(shift_left a (to_int_exn b)))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (shift_shape (-1l * b) 0l (!s))))
  | _ -> type_error "Procedure @lshift called with invalid parameters";;

(* TODO : add shape and group code *) 
let rshift (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Int(shift_right a (to_int_exn b)))
  | Shape(Atom(s))::Data(Int(b))::[] -> 
       Shape(Atom(n.pe.add_shape (shift_shape b 0l (!s))))
  | _ -> type_error "Procedure @rshift called with invalid parameters";;

(* TODO : add shape and group code *) 
let grt_than (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Bool(a > b))
  | _ -> type_error "Procedure @grt called with invalid parameters";;

(* TODO : add shape and group code *) 
let less_than (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::[] -> Data(Bool(a < b))
  | _ -> type_error "Procedure @lst called with invalid parameters";;


let rec eql (n : env) (vl : value list) : value = match vl with
  | Data(Int(a))::Data(Int(b))::[] -> Data(Bool(a = b))
  | Data(String(a))::Data(String(b))::[] -> Data(Bool(String.equal a b))
  | Data(Bool(a))::Data(Bool(b))::[] -> Data(Bool(Bool.equal a b))
  | Shape(a)::Shape(b)::[] -> Data(Bool(shape_eql (a,b)))
  | _ -> type_error "Procedure @eql called with invalid parameters"


(* TODO : Group equality is dependant on element order at the moment *)
and shape_eql : shape * shape ->  bool = function
  | (Group(al),Group(bl)) -> if (List.length al) <> (List.length bl) then false
                             else (List.for_all 
                                  (List.map2_exn al bl 
                                      (fun a b -> (Atom(a),Atom(b)))) shape_eql) 
  | (Atom(a),Atom(b)) -> (match (!a,!b) with
      | (Invalid,Invalid) -> true
      | (Line(a1,b1,c1,d1),Line(a2,b2,c2,d2)) -> 
            (a1 = a2) && (b1 = b2) && (c1 = c2) && (d1 = d2)
      | (Box(a1,b1,c1,d1),Box(a2,b2,c2,d2)) -> 
            (a1 = a2) && (b1 = b2) && (c1 = c2) && (d1 = d2)
      | (Ellipse(a1,b1,c1,d1),Ellipse(a2,b2,c2,d2)) -> 
            (a1 = a2) && (b1 = b2) && (c1 = c2) && (d1 = d2)
      | (Text(a1,b1,c1),Text(a2,b2,c2)) -> 
            (a1 = a2) && (b1 = b2) && (String.equal c1 c2)
      | _ -> false ) 
  | _ -> false;;


let neql (n : env) (vl : value list) : value = match (eql n vl) with
  | Data(Bool(b)) -> Data(Bool(not b))
  | _ -> assert false;;

let draw_line (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::Data(Int(c))::Data(Int(d))::[] ->
      Shape(Atom(n.pe.add_shape (Line(a,b,c,d))))
  | _ -> type_error "Procedure drawLine called with invalid parameters";;

let draw_box (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::Data(Int(c))::Data(Int(d))::[] ->
      Shape(Atom(n.pe.add_shape (Box(a,b,c,d))))
  | _ -> type_error "Procedure drawBox called with invalid parameters";;

let draw_ellipse (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::Data(Int(c))::Data(Int(d))::[] ->
      Shape(Atom(n.pe.add_shape (Ellipse(a,b,c,d))))
  | _ -> type_error "Procedure drawEllipse called with invalid parameters";;

let draw_text (n : env) (vl : value list) : value = match vl with 
  | Data(Int(a))::Data(Int(b))::Data(String(c))::[] ->
      Shape(Atom(n.pe.add_shape (Text(a,b,c))))
  | _ -> type_error "Procedure drawText called with invalid parameters";;

let destroy_shape  (n : env) (vl : value list) : value = match vl with 
  | Shape(Atom(a))::[] -> a := Invalid ; Data(Void)
  | Shape(Group(gl))::[] -> List.iter gl (fun a -> a := Invalid) ; Data(Void)
  | _ -> type_error "Procedure destroyShape called with invalid parameters";;

let clear_scene (n : env) (vl : value list) : value = match vl with 
  | [] -> let d = Hashtbl.Poly.data (!(n.table)) in
      List.iter d 
        (fun x -> match x with
                  | Shape(Atom(a)) -> a := Invalid
                  | Shape(Group(gl)) ->  List.iter gl (fun a -> a := Invalid)
        | _ -> () );
        Data(Void)
  | _ -> type_error "Procedure clearScene called with invalid parameters";;

 
(*
(* mandatory functions *)
val draw_line_connect : func
val draw_text_shape : func
val get_shape_x : func
val get_shape_y : func
val sin : func 
val cos : func 
val tan : func 
val asin : func 
val acos : func 
val atan : func 
val destroy_shape : func 
val clear_scene : func

(* optional functions *) 
val instance_of : func 
val draw_group : func 
val eval : func *)

