open Core.Std
open Ir
open Rterror

let wrap_int (i : int32) : value = Data(Int(i));;

let wrap_str (s : string) : value = Data(String(s));;

let wrap_bool (b : bool) : value = Data(Bool(b));;

let simple_print_shape = function 
  | Line(a,b,c,d) -> sprintf "Line(%d,%d,%d,%d)" 
                     (Int32.to_int_exn a) (Int32.to_int_exn b) 
                     (Int32.to_int_exn c) (Int32.to_int_exn d)
  | Box(a,b,c,d) -> sprintf "Box(%d,%d,%d,%d)" 
                     (Int32.to_int_exn a) (Int32.to_int_exn b) 
                     (Int32.to_int_exn c) (Int32.to_int_exn d)
  | Ellipse(a,b,c,d) -> sprintf "Ellipse(%d,%d,%d,%d)" 
                     (Int32.to_int_exn a) (Int32.to_int_exn b) 
                     (Int32.to_int_exn c) (Int32.to_int_exn d)
  | Text(a,b,c) -> sprintf "Text(%d,%d,\"%s\")" 
                     (Int32.to_int_exn a) (Int32.to_int_exn b) c
  | Invalid -> "Invalid"
;;

let simple_print_shapes sl = String.concat ~sep:"\n" (List.map sl simple_print_shape);;

let rec print_data : data -> string = function 
  | Void -> "Void" 
  | Int(i) -> sprintf "Int(%d)" (Int32.to_int_exn i)
  | Bool(b) -> (match b with 
                 | false -> "Bool(false)"
                 | true  -> "Bool(true)")
  | String(s) -> sprintf "String(%s)" s
  | Table(s) -> sprintf "Table(%s)" (print_table_innards s)

and print_table_innards t = 
  let (vl : (data * value) list) = Hashtbl.Poly.to_alist t in
  let (sl : string list) = List.map vl 
    (fun t -> let (k,v) = t in 
      sprintf "(%s => %s)" (print_data k) (print_value v)) in
  String.concat ~sep:";" sl

and print_value (v : value) : string = match v with 
  | Data(s) -> print_data s
  | Shape(s) -> print_shape s

and print_shape = function
  | Atom(a) -> simple_print_shape !a
  | Group(_) -> "Group";;

let print_values vl = String.concat ~sep:"," (List.map vl print_value);;

let binop_name : binop -> string = function
    Ast.Concat      -> "@cat"
  | Ast.Add         -> "@add"
  | Ast.Sub         -> "@sub" 
  | Ast.Mul         -> "@mul"
  | Ast.Mod         -> "@mod" 
  | Ast.Div         -> "@div"
  | Ast.Left_Shift  -> "@lsf"
  | Ast.Right_Shift -> "@rsf"
  | Ast.Eq          -> "@eql"
  | Ast.Neq         -> "@neq"
  | Ast.Gt          -> "@grt"
  | Ast.Lt          -> "@lst";;

let rec conv_expr : Ast.expr -> expr = function 
    Ast.Int(i) -> Val(wrap_int i)
  | Ast.String(s) -> Val(wrap_str s) 
  | Ast.None -> Val(Data(Void))
  | Ast.Bool(b) -> Val(wrap_bool b)
  | Ast.Ident(s) -> Ident(s)
  | Ast.Table(e) -> Call("@newTable",(conv_expr e)::[])
  | Ast.Table_Entry(e1,e2) -> Table_Entry(conv_expr e1,conv_expr e2)
  | Ast.Binop(e1,o,e2) -> Call(binop_name o,List.map [e1;e2] conv_expr)
  | Ast.Call(s,el) ->  Call(s,List.map el conv_expr);;

let rec conv_stmt : Ast.stmt -> stmt = function
    Ast.Declare(s) -> Declare(s) 
  | Ast.If(e,sl) -> If(conv_expr e,List.map sl conv_stmt)
  | Ast.While(e,sl) -> While(conv_expr e,List.map sl conv_stmt)
  | Ast.Return(e) -> Return(conv_expr e)
  | Ast.Expr_Stmt(e) -> Expr_Stmt(conv_expr e)
  | Ast.Assign(e1,e2) -> match e1 with
            Ast.Ident(s) -> Assign(s,conv_expr e2)
          | Ast.Table_Entry(et,ep) -> 
              Table_Assign( conv_expr et, conv_expr ep, conv_expr e2)
          | _ -> syntax_error "Assignment is of invalid form.";;

let conv_stmts sl = List.map sl conv_stmt;;

let rec eval_expr (n : env) : expr -> value = function
    Val(v) -> v
  | Ident(s) -> n.get s
  | Table_Entry(e1,e2) -> 
      let v1 = eval_expr n e1 in
      ( match v1 with
      | Data(Table(t)) -> let v2 = eval_expr n e2 in
              ( match v2 with
              | Data(d) -> (if Hashtbl.Poly.mem t d then
                              Hashtbl.Poly.find_exn t d
                            else 
                              type_error "Variable not found in table." )
              | _ -> type_error "Cannot use shapes or groups as table keys")
      | _ -> type_error "Tried to acess entry of a non table value")
  | Call(s,el) -> let vl = List.map el (eval_expr n) in
      (*printf "Calling into %s with (%s)\n" s (print_values vl);*)
      let v = (n.pe.get_func s) n vl in  
      (*printf "Return from %s with (%s)\n" s (print_value v);*) v;;

let rec eval_stmt (n : env) : stmt -> value option = function
  Declare(s) -> (* printf "init %s\n" s;*) n.init s; None
  | Assign(s,e) -> (* printf "assign %s\n" s; *) eval_assign n s e; None 
  | Expr_Stmt(e) -> ignore (eval_expr n e); None
  | Return(e) -> let v = eval_expr n e in 
            (*printf "returing %s\n" (print_value v);*) Some(v)
  | Table_Assign(et,ep,ev) -> eval_tbl_assgn n et ep ev
  | If(e,sl) -> eval_if n e sl
  | While(e,sl) -> eval_while n e sl
      
and eval_stmts (n : env) : stmt list -> value option = function
    [] -> None
  | x::xs -> let v = eval_stmt n x in match v with 
  | Some(r) -> Some(r)
  | None -> eval_stmts n xs

(* TODO : Make table assignment discriminate between shapes and other elements 
 *        - Explicit copies of shapes and groups *)

and eval_assign (n : env) (s : string) (e : expr) = 
  let v = eval_expr n e in match v with
  | Shape(Atom(a)) -> (match !a with 
      | Invalid -> destruction_error "Trying to assign destroyed variable" 
      | _ ->             let na = n.pe.add_shape (!a) in 
                          n.set s (Shape(Atom(na))))
  | Shape(Group(g)) -> let ng = List.map g 
                (fun a -> n.pe.add_shape (!a)) in 
                          n.set s (Shape(Group(ng)))
  | _ -> n.set s v 

and eval_tbl_assgn (n : env) (et : expr) (ep : expr) (ev : expr) : value option =
  let vt = eval_expr n et in
  match vt with
    | Data(Table(t)) -> let vp = eval_expr n ep in
      ( match vp with
      | Data(d) -> let vv = eval_expr n ev in
          Hashtbl.Poly.replace t d vv; None
      | _ -> type_error "Cannot use shapes or groups as table keys")
    | _ -> type_error "Cannot treat non-table object as table" 

and eval_if (n : env) (e : expr) (sl : stmt list) : value option =
  let v = eval_expr n e in 
  match v with 
    | Data(Bool(b)) -> if b then eval_stmts n sl else None
    | _ -> type_error "Non-Boolean Expression in If Statement"

and eval_while (n : env) (e : expr) (sl : stmt list) : value option = 
  let v = eval_expr n e in
  match v with 
     Data(Bool(b)) -> 
        (if b then 
              let r = eval_stmts n sl in 
              ( match r with 
              | Some(v) -> Some(v) 
              | None -> eval_stmt n (While(e,sl)))
            else 
              None)
    | _ -> type_error "Non-Boolean expression in While statement.";;


let rec new_env (prg : prog_env) : env = 
   let t = ref (Hashtbl.Poly.create ()) in
   { table = t;
     init = env_init_func t;
     set = env_set_func t;
     get = env_get_func t;
     get_all = env_get_all_func t;
     pe = prg
    } 

and env_init_func (t : envtable ref) : string -> unit = 
    (fun s -> if Hashtbl.Poly.mem !t s then 
        redeclaration_error 
          (sprintf "Variable \'%s\' has already been declared." s)
      else
         Hashtbl.Poly.replace !t ~key:s ~data:(Data(Void)))

and env_set_func (t : envtable ref) : string -> value -> unit = 
    (fun s v -> if Hashtbl.Poly.mem !t s then
        ((* printf "assign2 %s to %s \n" s (print_value v);
   printf "All Keys(%s)\n" (String.concat ~sep:"," (Hashtbl.Poly.keys !t)); *)
        Hashtbl.Poly.replace !t s v )
      else
        undeclared_var_error 
          (sprintf "Variable \'%s\' was never declared." s))

and env_get_func (t : envtable ref) : string -> value = 
    (fun s -> if Hashtbl.Poly.mem !t s then 
       (let v = Hashtbl.Poly.find_exn !t s in
       (* printf "getting %s from %s \n" (print_value v) s;*)
  (* printf "All Keys(%s)\n" (String.concat ~sep:"," (Hashtbl.Poly.keys !t));*)
        v)
      else
        undeclared_var_error 
          (sprintf "Variable \'%s\' was never declared." s))

and env_get_all_func (t : envtable ref) : unit -> value list =
  (fun s -> let vals = Hashtbl.Poly.data !t in 
   (* printf "Get All Keys(%s)\n" (String.concat ~sep:"," (Hashtbl.Poly.keys !t)); *)
  vals );;

let conv_func ?prop:(pr = false) (f : Ast.func) : env -> value list -> value = 
  let num_params = List.length f.Ast.params in
  let ir_bod = (conv_stmts f.Ast.body) in 
  (fun (sn : env) (vl : value list) -> 
      (* Test if the number of parameters are correct *)
      if num_params <> (List.length vl) then

        arity_error 
          (sprintf "Procedure \'%s\' called with incorrect number of parameters"
          f.Ast.name)
      else (
      (* Construct the function environment *)
      let n = (if pr then sn else new_env sn.pe) in 
      List.iter2_exn f.Ast.params vl 
        (fun name value -> n.init name; n.set name value;);
      (* Evaluate the function statements *)
      let rv = eval_stmts n ir_bod in

      (* Check if we got a valid return value. and return it
       *  otherwise return Void *)
      match rv with
      | Some(x) -> x
      | None -> Data(Void)
  ));;

let rec convert (p : Ast.prog) : prog_env = 
    let t = Hashtbl.Poly.create () in 
    let (sa : ((raw_shape ref) list) ref) = ref [] in
    (* add user created functions *)
    List.iter p (fun x -> 
      let nf = (if(String.equal x.Ast.name "main") then
                conv_func ~prop:true x else conv_func x) in
      Hashtbl.Poly.replace t x.Ast.name nf);
    (* add built in functions *)
      Hashtbl.Poly.replace t "@newTable" Funcs.new_table;
      Hashtbl.Poly.replace t "@cat" Funcs.cat;
      Hashtbl.Poly.replace t "@add" Funcs.add;
      Hashtbl.Poly.replace t "@sub" Funcs.sub;
      Hashtbl.Poly.replace t "@mul" Funcs.mul;
      Hashtbl.Poly.replace t "@mod" Funcs.modulo;
      Hashtbl.Poly.replace t "@div" Funcs.div;
      Hashtbl.Poly.replace t "@lsf" Funcs.lshift;
      Hashtbl.Poly.replace t "@rsf" Funcs.rshift;
      Hashtbl.Poly.replace t "@eql" Funcs.eql;
      Hashtbl.Poly.replace t "@neq" Funcs.neql;
      Hashtbl.Poly.replace t "@grt" Funcs.grt_than;
      Hashtbl.Poly.replace t "@lst" Funcs.less_than;
      Hashtbl.Poly.replace t "drawLine" Funcs.draw_line;
      Hashtbl.Poly.replace t "drawBox" Funcs.draw_box;
      Hashtbl.Poly.replace t "drawEllipse" Funcs.draw_ellipse;
      Hashtbl.Poly.replace t "drawText" Funcs.draw_text;
      Hashtbl.Poly.replace t "destroyShape" Funcs.destroy_shape;
      Hashtbl.Poly.replace t "clearScene" Funcs.clear_scene;
    {  add_shape = conv_add_shape sa ;
       get_func = (fun s -> if Hashtbl.Poly.mem t s then 
        Hashtbl.Poly.find_exn t s
      else
        undeclared_var_error 
          (sprintf "Function \'%s\' was never declared." s))
    } 

and conv_add_shape (sa : ((raw_shape ref) list) ref) : raw_shape -> raw_shape ref =
  (fun s -> let sr = ref s in sa := sr :: (!sa); sr);; 

let rec filter_values (vl : value list) : raw_shape list = match vl with
  | [] -> []
  | Shape(Atom(a))::xs -> !a :: (filter_values xs)
  | _::xs -> filter_values xs;;


let execute (p : Ir.prog_env) (w :int32) (h : int32) : raw_shape list =
  let n = new_env p in 
  let main = p.get_func "main" in
  ignore (main n [Data(Int(w));Data(Int(h))]);(
  let vl = n.get_all () in
  filter_values vl);;

 
