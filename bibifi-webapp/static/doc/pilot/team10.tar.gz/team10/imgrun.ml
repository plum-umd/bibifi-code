open Core.Std
open Rterror
open Astutil
open Irutils

let main (_ : unit)  : unit = 
    let prog = (parse_file Sys.argv.(1)) in
        if not (validate prog) then (syntax_error "invalid functions");
    let w = (int_of_string Sys.argv.(2)) in
    let h = (int_of_string Sys.argv.(3)) in
    (* printf "%s" (print_prog prog); *)
    let irprog = (convert prog) in
    let output = (execute irprog (Int32.of_int_exn w) (Int32.of_int_exn h))in
    printf "%s\n" (Svg.to_svg w h output);;

let () = handle_runtime_errors main;


