open Core.Std
open Ast

open Lexer
open Lexing

let print_position outx lexbuf =
  let pos = lexbuf.lex_curr_p in
  fprintf outx "%s:%d:%d" pos.pos_fname
    pos.pos_lnum (pos.pos_cnum - pos.pos_bol + 1);;

let parse_with_error lexbuf =
  try Parser.prog Lexer.token lexbuf with
  (*| Lexer.SyntaxError msg ->
    fprintf stderr "%a: %s\n" print_position lexbuf msg;
    exit (-1) *)
  | e ->
      fprintf stderr "%a: syntax error\n" print_position lexbuf;
    exit (-1);;

let parse_file (name : string) : prog = 
  let chan = In_channel.create name in 
  let lexbuf = Lexing.from_channel chan in
  lexbuf.lex_curr_p <- { lexbuf.lex_curr_p with pos_fname = name };
  let (p : prog) = parse_with_error lexbuf in
    In_channel.close chan ; p ;;

let print_binop : binop -> string = function 
    Concat      -> "++"
  | Add         -> "+"
  | Sub         -> "-"
  | Mul         -> "*" 
  | Mod         -> "%"
  | Div         -> "/"
  | Left_Shift  -> "<<"
  | Right_Shift -> ">>"
  | Eq          -> "=="
  | Neq         -> "!="
  | Gt          -> ">"
  | Lt          -> "<";;

let rec print_expr : expr -> string = function
    Int(i)              -> Int32.to_string i
  | String(s)           -> sprintf "\"%s\"" s
  | None                -> "none"
  | Bool(b)             -> ( match b with
                           | true -> "true"
                           | false -> "false" )
  | Ident(s)            -> s
  | Table(e)            -> sprintf "[%s]" (print_expr e)
  | Table_Entry(e1,e2)  -> sprintf "(%s).(%s)" (print_expr e1) (print_expr e2)
  | Binop(e1,b,e2)      -> sprintf "(%s) %s (%s)" 
                                   (print_expr e1) 
                                   (print_binop b) 
                                   (print_expr e2)
  | Call(s,el)          -> sprintf "%s(%s)"  s
                                   (print_expr_list el)

and print_expr_list : expr list -> string = function
    []                  -> ""
  | x::[]               -> print_expr x
  | x::xs               -> sprintf "%s , %s"
                                   (print_expr x)
                                   (print_expr_list xs);;


let rec printi_stmt (indent : int) : stmt -> string =
  let ind = String.create (indent * 3) in
  String.fill ind 0 (indent * 3) ' ';
  function
    Declare(s)          -> sprintf "%s var %s;\n" ind s
  | Assign(e1,e2)       -> sprintf "%s %s = %s;\n" ind 
                                   (print_expr e1)
                                   (print_expr e2)
  | If(e,sl)            -> sprintf "%s if( %s ) {\n %s%s }\n" ind
                                   (print_expr e)
                                   (printi_stmts (indent + 1) sl) ind
  | While(e,sl)         -> sprintf "%s while( %s ) {\n%s%s }\n" ind
                                   (print_expr e)
                                   (printi_stmts (indent + 1) sl) ind
  | Return(e)           -> sprintf "%s return %s ;\n" ind
                                   (print_expr e)
  | Expr_Stmt(e)        -> sprintf "%s %s ;\n" ind
                                   (print_expr e)
and printi_stmts (indent : int) (sl : stmt list) : string =
  String.concat (List.map sl (printi_stmt indent)) ;;

let print_stmt : stmt -> string = printi_stmt 0;;
let print_stmts : stmt list -> string = printi_stmts 0;;

let print_idents (il : ident list) : string = 
  String.concat ~sep:" , " il;;

let print_func (f : func) : string = 
  sprintf "def %s ( %s )  {\n%s}\n" f.name
  (print_idents f.params) (printi_stmts 1 f.body);;

let print_prog (p : prog) : string = 
  String.concat ~sep:"\n\n" (List.map p print_func);;

let rec validate2 : prog -> bool = function
    []      -> false
  | x::xs   -> (List.for_all xs (fun y -> x.name <> y.name)) && (xs = [] ||
  (validate2 xs));;

let rec validate : prog -> bool = function
    []      -> false
  | p       -> (List.exists p (fun x -> x.name = "main")) && (validate2 p)
