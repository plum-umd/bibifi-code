open Printf
open Scanf
open Parser_util
open Eval
open Lang

let main () =
  try begin 
    let filename = ref "" in
    let width = ref 0 in
    let height = ref 0 in
    if Array.length Sys.argv != 4 then begin printf "need filename width height\n%!"; exit 70 end;
    sscanf Sys.argv.(1) "%s" (fun f -> filename := f);
    sscanf Sys.argv.(2) "%d" (fun w -> width := w);
    sscanf Sys.argv.(3) "%d" (fun h -> height := h);

    let procs = begin
      try parse_file !filename Parser.progfile
      with Parse_error -> exit 10 end in

    let r = eval_prog !width !height procs in

    print_string begin
      "<?xml version=\"1.0\"?>\n"
      ^ (sprintf "<svg viewBox=\"0 0 %d %d\"" !width !height) ^ " xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n"
      ^ "<g stroke=\"black\" fill=\"black\">\n" end;

    print_string r;

    print_string begin 
      "</g>\n"
      ^ "</svg>\n" end;

    exit 0

  end with 
    | Syntax_error -> exit 10
    | Type_error msg -> eprintf "%s\n%!" msg; exit 20
    | ShapeDestroyed_error -> exit 30
    | TableSize_error -> exit 40
    | Undefined_error -> exit 50
    | Redefined_error -> exit 60
;;

main();;
