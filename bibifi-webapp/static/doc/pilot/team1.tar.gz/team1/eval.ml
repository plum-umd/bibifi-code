open Printf
open State
open Lang
open Library
open Parser_util
open Parser

let unbox_valueshapesomegroup x = match x with
  | VShape sref -> begin
    match !sref with
      | Some (ShapeGroup sl) -> sl
      | None -> raise ShapeDestroyed_error
      | _ -> raise (Type_error "group shape expected")
  end
  | _ -> raise (Type_error "shape expected")

let rec eval_stmt s astmt =
  match astmt with
    | SDefine id -> s#def_bind id
    | SAssign (e1, e2) ->
      let v1 = eval_lexp s e1 in
      let v2 = eval_exp s e2 in
      begin match v1 with
        | LVVariable id ->
          s#set_bind id (copy_value v2)
        | LVTableElement (t,k) ->
          Hashtbl.replace t k (check_for_destroyed v2)
      end
    | SIf (e1, s1) -> begin
      match eval_exp s e1 with
        | VBool true -> eval_stmt s s1
        | VBool false -> ()
        | _ -> raise (Type_error "if expects boolean guard") end
    | SWhile (e1, s1) -> begin
      match eval_exp s e1 with
        | VBool true ->
          eval_stmt s s1; 
          eval_stmt s astmt
        | VBool false -> ()
        | _ -> raise (Type_error "while expects boolean guard") end
    | SForeach (id, e1, body) ->
      let v1 = eval_exp s e1 in
      let sl = unbox_valueshapesomegroup v1 in 
      List.iter (fun optref ->
        match !optref with
          | Some (ShapeGroup _) ->
            eval_stmt s (SForeach (id, EConst (VShape optref), body))
          | Some ashape ->
            s#def_bind id;
            s#set_bind id (VShape optref);
            eval_stmt s body;
            s#delete_bind id
          | None -> ()) sl
    | SReturn e1 ->
      raise (Return (eval_exp s e1))
    | SSeq (sl) ->
      List.iter (eval_stmt s) sl
    | SExp e1 -> ignore (eval_exp s e1)

and eval_lexp s aexp = match aexp with
  | EIdent id -> LVVariable id
  | ETableIndex (e1, e2) ->
    let t = eval_exp s e1 in
    let k = eval_exp s e2 in
    begin 
      match t with
        | VTable t -> LVTableElement (t, k)
        | _ -> raise (Type_error "need table to do table lookup")
    end
  | _ -> raise (Type_error "expected lvalue")

and eval_exp s aexp = match aexp with
  | EConst v -> v
  | EIdent id -> s#get_bind id
  | ETableNew e1 ->
    let v1 = eval_exp s e1 in
    begin 
      match v1 with
        | VInt size -> 
          if size < 0 then raise TableSize_error;
          let size =
            if size > 1024 * 1024 then 1024 * 1024 else size in
          VTable (Hashtbl.create size)
        | _ -> raise (Type_error "table size needs to be an int")
    end
      
  | ETableIndex (e1, e2) ->
    let v1 = eval_exp s e1 in
    let v2 = eval_exp s e2 in
    begin
      match v1 with
        | VTable t ->
          begin try Hashtbl.find t v2 
            with Not_found -> raise Undefined_error end
        | _ -> raise (Type_error "need table to lookup from")
    end
  | EBinop (opname, e1, e2) ->
    let v1 = eval_exp s e1 in
    let v2 = eval_exp s e2 in
    let t1 = type_of_value v1 in
    let t2 = type_of_value v2 in
    let imp = Library.get_binop_imp opname t1 t2 in
    imp v1 v2
  | EApp ("eval", elist) ->
    begin match elist with
      | e1 :: [] ->
        let v1 = eval_exp s e1 in
        begin match v1 with
          | VString astring -> begin
            try
              let astmt = parse_string astring Parser.stmt in
              eval_stmt s astmt;
              VNone
            with
              | Return v -> v
              | Parse_error -> begin
                let aexp = parse_string astring Parser.exp in
                eval_exp s aexp
              end
          end
          | _ -> raise (Type_error "eval expects string argument")
        end
      | _ -> raise (Type_error "eval expects one argument")
    end
  | EApp ("clearScene", elist) ->
    begin match elist with
      | [] -> ()
      | _ -> raise (Type_error "clearScene takes no arguments")
    end;
    s#iter_binds
      (fun id v ->
        match v with
          | VShape s -> ignore (lib_destroyShape [v])
          | _ -> ());
    VNone
  | EApp (id, elist) ->
    let imp =
      begin try s#get_proc id 
        with Not_found -> begin
          try Library.get_app_imp id 
          with Not_found -> raise Undefined_error
        (* todo: what error code to return here was not specified *)
        end
      end in
    let vlist = List.map (eval_exp s) elist in
    imp vlist

let rec eval_prog w h proclist =
  let s = new state in
  s#def_procs eval_stmt proclist;

  let main_option = s#get_main () in
  match main_option with
    | None -> raise Syntax_error
    | Some (args, body) -> begin
      match args with
        | arg1 :: arg2 :: [] ->
          s#def_bind arg1; s#set_bind arg1 (VInt w);
          s#def_bind arg2; s#set_bind arg2 (VInt h);
          eval_stmt s body;
          (*eprintf "%s\n" (s#to_string);*)
          s#render ()
          
        | _ -> raise Syntax_error
    end
