open Lang
open Printf

type bindings = (ident, value) Hashtbl.t

type proctype = value list -> value

let rec render_shape s =
  match s with
    | ShapeLine ((x1, y1), (x2, y2)) ->
      sprintf "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\"/>\n"
        x1 y1 x2 y2
    | ShapeEllipse ((cx, cy), rx, ry) ->
      sprintf "<ellipse cx=\"%d\" cy=\"%d\" rx=\"%d\" ry=\"%d\"/>\n"
        cx cy rx ry
    | ShapeBox ((cx, cy), w, h) ->
      sprintf "<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\"/>\n"
        cx cy w h
    | ShapeText ((cx, cy), t) ->
      sprintf "<text x=\"%d\" y=\"%d\">%s</text>\n"
        cx cy (Util.escape_xml t)
    | ShapeGroup sl ->
      String.concat ""
        (List.map
           (fun sref -> match !sref with
             | None -> ""
             | Some s -> render_shape s)
           sl)

class state = object (self)
  val mutable binds: (ident, value) Hashtbl.t = Hashtbl.create 10
  val mutable procs: (ident, proctype) Hashtbl.t = Hashtbl.create 10
  val mutable main: (ident list * stmt) option = None

  method stack_binder eval_stmt idlist astmt vallist =
    let old_binds = binds in
    binds <- Hashtbl.create 10;

    begin
      try List.iter2
            (fun id aval ->
              self#def_bind id;
              self#set_bind id aval)
            idlist vallist 
      with Invalid_argument _ -> raise (Type_error "proc arity mismatch") end;
    let ret =
      begin
        try eval_stmt self astmt;
            VNone
        with
          | Return v -> v
      end in
    binds <- old_binds;
    ret
      
  method def_procs (eval_stmt: 'a -> stmt -> unit) proclist =
    List.iter
      (fun (PDef (id, args, body)) ->
        if Hashtbl.mem procs id then raise Eval_error;
        if id = "main" then begin
          main <- Some (args, body)
        end else begin
          Hashtbl.replace procs id
            (self#stack_binder eval_stmt args body)
        end)
      proclist

  method get_proc id = Hashtbl.find procs id 

  method get_main () = main

  method def_bind id =
    if Hashtbl.mem binds id then
      raise Redefined_error
    else begin
      Hashtbl.replace binds id VNone
    end

  method set_bind id aval =
    begin
      try ignore (Hashtbl.find binds id)
      with Not_found -> raise Undefined_error
    end;
    Hashtbl.replace binds id aval;

  method get_bind id =
    try Hashtbl.find binds id
    with Not_found -> raise Undefined_error

  method delete_bind id =
    if Hashtbl.mem binds id then
      Hashtbl.remove binds id
    else raise Eval_error

  method iter_binds f =
    Hashtbl.iter f binds

  method render () =
    let ret = ref "" in
    Hashtbl.iter 
      (fun id v ->
        match v with
          | VShape sr ->
            begin 
              match !sr with
                | Some s -> ret := !ret ^ (render_shape s)
                | _ -> ()
                  end
          | _ -> ())
      binds;
    !ret
end
;;
