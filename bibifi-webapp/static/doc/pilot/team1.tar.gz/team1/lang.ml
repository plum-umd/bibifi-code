open Printf
open Util

exception Syntax_error
exception Type_error of string
exception ShapeDestroyed_error
exception TableSize_error
exception Undefined_error
exception Redefined_error

exception Eval_error

type dt =
  | TValue
    | TShape
      | TAtomic
        | TLine
        | TText
        | TBox
        | TEllipse
      | TGroup
    | TData
      | TVoid
      | TInt
      | TString
      | TBool
      | TTable

type ident = string

type coord = int * int

type shape =
  | ShapeLine of coord * coord
  | ShapeBox of coord * int * int
  | ShapeEllipse of coord * int * int
  | ShapeText of coord * string
  | ShapeGroup of ((shape option) ref) list

and table = (value, value) Hashtbl.t

and lvalue =
  | LVVariable of ident
  | LVTableElement of table * value

and value =
  | VInt of int
  | VString of string
  | VBool of bool
  | VNone
  | VShape of (shape option) ref
  | VTable of table

and exp =
  | EConst of value
  | EIdent of ident
  | ETableNew of exp
  | ETableIndex of exp * exp
  | EBinop of string * exp * exp
  | EApp of ident * (exp list)
and stmt = 
  | SDefine of ident
  | SAssign of exp * exp
  | SIf of exp * stmt
  | SWhile of exp * stmt
  | SForeach of ident * exp * stmt
  | SReturn of exp
  | SSeq of stmt list
  | SExp of exp
and proc =
  | PDef of ident * (ident list) * stmt

exception Return of value

let type_of_value v =
  match v with
    | VInt _ -> TInt
    | VString _ -> TString
    | VBool _ -> TBool
    | VNone -> TVoid
    | VShape _ -> TShape
    | VTable _ -> TTable

let type_of_value_exact v =
  match v with
    | VShape s ->
      begin match !s with
        | None -> raise ShapeDestroyed_error
        | Some (ShapeLine _) -> TLine
        | Some (ShapeBox _)  -> TBox
        | Some (ShapeEllipse _) -> TEllipse
        | Some (ShapeText _) -> TText
        | Some (ShapeGroup _) -> TGroup
      end
    | _ -> type_of_value v
  
let unbox_shape s =
  match !s with
    | Some s -> s
    | None -> raise ShapeDestroyed_error

let box_shape s =
  VShape (ref (Some s))

let copy_shape v =
  match v with
    | VShape s -> box_shape (unbox_shape s)
    | _ -> raise (Type_error "shape expected")

let copy_value v =
  match v with
    | VShape s -> box_shape (unbox_shape s)
    | _ -> v

let check_for_destroyed v =
  match v with
    | VShape s -> ignore (unbox_shape s); v
    | _ -> v
