open Str

let string_split s split_on =
  let r = regexp_string split_on in
  split r s

let string_indent tab s =
  let pieces = string_split s "\n" in
  tab ^ (String.concat ("\n" ^ tab) pieces)

let escape_xml s =
  let s = global_replace (regexp_string "&") "&amp;" s in
  let s = global_replace (regexp_string ">") "&lt;" s in
  let s = global_replace (regexp_string "<") "&gt;" s in
  let s = global_replace (regexp_string "'") "&apos;" s in
  let s = global_replace (regexp_string "\"") "&quot;" s in
  s
