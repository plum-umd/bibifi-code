open Lang
open State

let pi = 4.0 *. (atan 1.0);;

let imp_true = fun _ _ -> VBool true;;
let imp_false = fun _ _ -> VBool false;;

let shape_eq s1 s2 = match (s1, s2) with
  | (ShapeLine _, ShapeLine _)
  | (ShapeBox _, ShapeBox _)
  | (ShapeEllipse _, ShapeEllipse _)
  | (ShapeText _, ShapeText _) -> s1 = s2
  | _ -> false

let imp_eq v1 v2 =
  VBool begin
  match (v1, v2) with
    | (VInt i1, VInt i2) -> i1 = i2
    | (VString s1, VString s2) -> s1 = s2
    | (VBool b1, VBool b2) -> b1 = b2
    | (VShape s1, VShape s2) ->
      shape_eq
        (unbox_shape s1)
        (unbox_shape s2)
    | (VNone, VNone) -> true
    | _ -> false
  end
let imp_neq a b = match imp_eq a b with
  | VBool true -> VBool false
  | VBool false -> VBool true
  | _ -> raise (Type_error "!= expects bool")
  
let supertype t = match t with
  | TLine -> TAtomic
  | TText -> TAtomic
  | TBox -> TAtomic
  | TEllipse -> TAtomic
  | TGroup -> TShape
  | TAtomic -> TShape
  | TShape -> TValue
  | TVoid -> TData
  | TInt -> TData
  | TString -> TData
  | TBool -> TData
  | TTable -> TData
  | TData -> TValue
  | TValue -> TValue

let rec is_subtype t1 t2 = 
  if t1 = t2 then true else
    let t1s = supertype t1 in
    if t1s = t1 then false else is_subtype t1s t2

let type_of_string s = match s with
  | "value" -> TValue
  | "shape" -> TShape
  | "atomic" -> TAtomic
  | "line" -> TLine
  | "text" -> TText
  | "box" -> TBox
  | "ellipse" -> TEllipse
  | "group" -> TGroup
  | "data" -> TData
  | "void" -> TVoid
  | "int" -> TInt
  | "string" -> TString
  | "bool" -> TBool
  | "table" -> TTable
  | _ -> raise Not_found

let imp_instance_of v1 s2 =
  let t1 = type_of_value_exact v1 in
  match s2 with
    | VString s2 ->
      begin 
        try let t2 = type_of_string s2 in
            VBool (is_subtype t1 t2)
        with Not_found -> VBool false
      end
    | _ -> raise
      (Type_error "second arg to instanceOf needs to be a string")

let lib_concat s1 s2 = match (s1, s2) with
  | (VString s1, VString s2) -> VString (s1 ^ s2)
  | _ -> failwith "should not happen"

let int_fun imp i1 i2 = match (i1, i2) with
  | (VInt i1, VInt i2) -> VInt (imp i1 i2)
  | _ -> failwith "should not happen"
let lib_plus = int_fun (+)
let lib_minus = int_fun (-)
let lib_mult = int_fun ( * )
let lib_divide = int_fun (/)
let lib_remainder = int_fun (mod)
let lib_lshift = int_fun (lsl)
let lib_rshift = int_fun (lsr)

let int_rel imp i1 i2 = match (i1, i2) with
  | (VInt i1, VInt i2) -> VBool (imp i1 i2)
  | _ -> failwith "should not happen"
let lib_less_than = int_rel (<)
let lib_greater_than = int_rel (>)

let coords_op op (x1,y1) (x2,y2) =
  (op x1 x2, op y1 y2)
let coords_add = coords_op (+)
let coords_mult = coords_op ( * )
let coords_div = coords_op (/)

let rec shape_coords_op op s =
  match s with
    | ShapeLine (c1, c2) -> ShapeLine (op c1, op c2)
    | ShapeBox (c, w, h) -> ShapeBox (op c, w, h)
    | ShapeEllipse (c, w, h) -> ShapeEllipse (op c, w, h)
    | ShapeText (c, text) -> ShapeText (op c, text)
    | ShapeGroup cl ->
      ShapeGroup
        (List.map
           (fun sref -> match !sref with
             | Some s -> ref (Some (shape_coords_op op s))
             | None -> failwith "should not happen")
           (List.filter
              (fun sref -> match !sref with
                | Some _ -> true
                | None -> false)
              cl))

let lib_translate_x m s x =
  match (s, x) with
    | (VShape s, VInt x) ->
      box_shape (shape_coords_op (coords_add (m * x, 0)) (unbox_shape s))
    | _ -> raise (Type_error "translate x expects shape and int")
let lib_translate_y m s y = 
  match (s, y) with
    | (VShape s, VInt y) ->
      box_shape (shape_coords_op (coords_add (0, m * y)) (unbox_shape s))
    | _ -> raise (Type_error "translate y expects shape and int")
let lib_scale_up s f = 
  match (s, f) with
    | (VShape s, VInt f) ->
      box_shape (shape_coords_op (coords_mult (f, f)) (unbox_shape s))
    | _ -> raise (Type_error "scale up expects shape and int")
let lib_scale_down s f =
  match (s, f) with
    | (VShape s, VInt f) ->
      box_shape (shape_coords_op (coords_div (f, f)) (unbox_shape s))
    | _ -> raise (Type_error "scale down expects shape and int")

let binops_list =
  [("++", TString, TString, lib_concat);
   ("+",  TInt,    TInt,    lib_plus);
   ("+",  TShape,  TInt,    lib_translate_y 1);
   ("-",  TInt,    TInt,    lib_minus);
   ("-",  TShape,  TInt,    lib_translate_y (-1));
   ("*",  TInt,    TInt,    lib_mult);
   ("*",  TShape,  TInt,    lib_scale_up);
   ("%",  TInt,    TInt,    lib_remainder);
   ("/",  TInt,    TInt,    lib_divide);
   ("/",  TShape,  TInt,    lib_scale_down);
   ("<<", TInt,    TInt,    lib_lshift);
   ("<<", TShape,  TInt,    lib_translate_x (-1));
   (">>", TInt,    TInt,    lib_rshift);
   (">>", TShape,  TInt,    lib_translate_x 1);
   ("<",  TInt,    TInt,    lib_less_than);
   (">",  TInt,    TInt,    lib_greater_than)];;

let binops_hash = Hashtbl.create (List.length binops_list);;
let () = List.iter
  (fun (opname, t1, t2, imp) -> Hashtbl.replace binops_hash (opname, t1, t2) imp)
  binops_list

let get_binop_imp opname t1 t2 = match opname with
  | "==" -> imp_eq
  | "!=" -> imp_neq
  | "instanceOf" -> imp_instance_of
  | _ -> Hashtbl.find binops_hash (opname, t1, t2)

let unbox_4int vlist =
  match vlist with
    | VInt v1 :: VInt v2 :: VInt v3 :: VInt v4 :: [] ->
      (v1, v2, v3, v4)
    | _ -> raise (Type_error "expected 4 ints")

let lib_drawLine vlist =
  let (v1, v2, v3, v4) = unbox_4int vlist in
  box_shape (ShapeLine ((v1, v2), (v3, v4)))
let lib_drawBox vlist = 
  let (v1, v2, v3, v4) = unbox_4int vlist in
  box_shape (ShapeBox ((v1, v2), v3, v4))
let lib_drawEllipse vlist = 
  let (v1, v2, v3, v4) = unbox_4int vlist in
  box_shape (ShapeEllipse ((v1, v2), v3, v4))

let lib_drawText vlist = 
  match vlist with
    | VInt v1 :: VInt v2 :: VString v3 :: [] ->
      box_shape (ShapeText ((v1, v2), v3))
    | _ -> raise (Type_error "drawText expects coord and string")

let shape_center ashape = match ashape with
  | ShapeLine ((v1, v2), (v3, v4)) -> ((v1 + v3) / 2, (v2 + v4) / 2)
  | ShapeBox ((v1, v2), v3, v4) -> (v1 + (v3 / 2), (v2 + (v4 / 2)))
  | ShapeEllipse ((v1, v2), _, _) -> (v1, v2)
  | ShapeText ((v1, v2), _) -> (v1, v2)
  | ShapeGroup _ -> raise (Type_error "cannot take shape center of group")

let lib_drawLineConnectingShapes vlist =
  match vlist with
    | VShape s1 :: VShape s2 :: [] ->
      let c1 = shape_center (unbox_shape s1) in
      let c2 = shape_center (unbox_shape s2) in
      box_shape (ShapeLine (c1, c2))
    | _ -> raise (Type_error "drawLineConnectingShapes expects 2 shapes")

let lib_drawTextOnShape vlist =
  match vlist with
    | VShape s1 :: VString text :: [] ->
      box_shape (ShapeText (shape_center (unbox_shape s1), text))
    | _ -> raise (Type_error "drawTextOneShape expects shape and string")

let lib_getShapeXCoordinate vlist =
  match vlist with
    | VShape s :: [] ->
      let (x,_) = shape_center (unbox_shape s) in
      VInt x
    | _ -> raise (Type_error "getShapeXCoordinate expects shape")

let lib_getShapeYCoordinate vlist =
  match vlist with
    | VShape s :: [] ->
      let (_,y) = shape_center (unbox_shape s) in
      VInt y
    | _ -> raise (Type_error "getShapeYCoordinate expects shape")
      
let lib_trig rimp vlist = match vlist with
  | VInt i :: [] -> VInt
    (int_of_float ((180.0 /. pi) *. (rimp ((float_of_int i) *. (pi /. 180.0)))))
  | _ -> raise (Type_error "trig function expects int")

let lib_destroyShape vlist = 
  match vlist with
    | VShape s :: [] ->
      begin match !s with
        | Some ashape -> s := None; VNone
        | None -> raise ShapeDestroyed_error
      end
    | _ -> raise (Type_error "destroyShape expects shape")

let lib_drawGroup vlist =
  let srefs_list =
    List.map (fun v -> match v with
      | VShape sref -> begin
        match !sref with
          | Some s -> sref
          | None -> raise ShapeDestroyed_error end
      | _ -> raise (Type_error "drawGroup expects shapes")) vlist in

  VShape (ref (Some (ShapeGroup srefs_list)))
    
let apps_list =
  [("drawLine", lib_drawLine);
   ("drawBox", lib_drawBox);
   ("drawEllipse", lib_drawEllipse);
   ("drawText", lib_drawText);
   ("drawLineConnectingShapes", lib_drawLineConnectingShapes);
   ("drawTextOnShape", lib_drawTextOnShape);
   ("getShapeXCoordinate", lib_getShapeXCoordinate);
   ("getShapeYCoordinate", lib_getShapeYCoordinate);
   ("sin", lib_trig sin);
   ("cos", lib_trig cos);
   ("tan", lib_trig tan);
   ("arcsin", lib_trig asin);
   ("arccos", lib_trig acos);
   ("arctan", lib_trig atan);
   ("destroyShape", lib_destroyShape);
   ("drawGroup", lib_drawGroup)];;

let apps_hash = Hashtbl.create (List.length apps_list);;
let () = List.iter
  (fun (id, imp) -> Hashtbl.replace apps_hash id imp)
  apps_list

let get_app_imp id = Hashtbl.find apps_hash id

