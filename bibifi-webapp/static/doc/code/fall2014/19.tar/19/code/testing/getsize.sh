#!/bin/bash

ls -al | egrep '[A-Z]{8}' | awk '{COUNTER+=$5} END {print COUNTER}'
