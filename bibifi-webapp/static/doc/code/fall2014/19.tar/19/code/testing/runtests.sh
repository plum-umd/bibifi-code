#!/bin/bash

for i in some_tests/{core,edge_tests,perf}/*.xml
do
    echo "./check_test.py  --prefix . --xml $i"
    echo -n "$i: "
    ./check_test.py  --prefix . --xml $i | egrep -o '^(pass.*|fail.*)'
done
