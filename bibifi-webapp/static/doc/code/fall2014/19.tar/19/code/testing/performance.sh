#!/bin/bash

pushd `dirname $0`/.. > /dev/null
BASE=`pwd`
popd > /dev/null

pushd ${BASE}/build
make quick
popd > /dev/null

echo $1

mkdir -p ${BASE}/testing/perf-results/$1
pushd ${BASE}/testing/perf-results/$1
for x in ${BASE}/testing/some_tests/perf/*.xml
do
    echo `basename $x`
    /usr/bin/time -o `basename $x`.time ${BASE}/testing/check_test.py --prefix ${BASE}/build --xml $x 2> /dev/null > /dev/null
done
popd > /dev/null
