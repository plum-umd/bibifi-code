module Main where

import Test.Framework
import Data.Monoid

main :: IO ()
main = defaultMainWithOpts
  [ 
  ] mempty
