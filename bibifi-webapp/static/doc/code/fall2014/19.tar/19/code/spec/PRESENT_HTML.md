logread -A HTML
===============
Should output HTML with a table, where each row in the table is the name of an employee. These should be printed in lexicographic order.

    <html>
    <body>
    <table>
    <tr>
      <th>Employees</th>
    </tr>
    <tr>
      <td>Employee1</td>
    </tr>
    <tr>
      <td>Employee2</td>
    </tr>
    </table>
    </body>
    </html>
