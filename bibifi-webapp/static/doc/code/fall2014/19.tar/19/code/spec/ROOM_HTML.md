logread -R HTML
===============
Should output HTML with a table, where each row in the table is a room ID.

    <html>
    <body>
    <table>
    <tr>
      <th>Rooms</th>
    </tr>
    <tr>
      <td>1</td>
    </tr>
    <tr>
      <td>2</td>
    </tr>
    <tr>
      <td>1</td>
    </tr>
    <tr>
      <td>3</td>
    </tr>
    </table>
    </body>
    </html>
