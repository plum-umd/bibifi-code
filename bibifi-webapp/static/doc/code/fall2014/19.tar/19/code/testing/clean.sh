#!/bin/bash

FILES=`ls | egrep '[A-Z]{8}'`
for f in $FILES; do
  rm $f
done
