logread -B HTML
===============
Should output HTML with a table, where each row in the table is the name of an employee. These should be printed in lexicographic order.

    <html>
    <body>
    <table>
    <tr>
      <th>Employees</th>
    </tr>
    <tr>
      <td>James</td>
    </tr>
    <tr>
      <td>Matt</td>
    </tr>
    </table>
    </body>
    </html>
