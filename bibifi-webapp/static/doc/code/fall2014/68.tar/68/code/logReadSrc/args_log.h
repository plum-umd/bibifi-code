#ifndef ARGS_LOG_H_
#define ARGS_LOG_H_

#include "definitions.h"

logappend_args opt_parser_log(int32_t argc, char **argv);
void * toString(logappend_args* args);



#endif /* ARGS_LOH_H_ */
