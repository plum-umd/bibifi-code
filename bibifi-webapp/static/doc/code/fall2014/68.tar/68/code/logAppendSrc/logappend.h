/*
 * logappend.h
 *
 *  Created on: Aug 30, 2014
 *      Author: kevin
 */

#ifndef LOGAPPEND_H_
#define LOGAPPEND_H_

int run_me(int argc, char * argv[]);


#endif /* LOGAPPEND_H_ */
