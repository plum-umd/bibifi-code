//Credit: github.com/dafrancis


#ifndef __color_h__
#define __color_h__
 
#define RED    "\e[31m"
#define GREEN  "\e[32m"
#define YELLOW "\e[33m"
#define WHITE  "\e[1m"
 
#define COLOR_X "\e[m"
 
#endif

